package fr.kny.menu;

import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class WpandamListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof WpandamMenuHolder)) return;

        // Empêche de prendre/déplacer les items du menu
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType().isAir()) return;

        // Ignore les placeholders (verre gris "Bientôt disponible")
        if (clicked.getType() == org.bukkit.Material.GRAY_STAINED_GLASS_PANE) return;

        // Donne une copie de l'item au joueur
        player.getInventory().addItem(clicked.clone());
        player.sendMessage(Component.text("§a✔ Item ajouté à ton inventaire."));
    }
}