package fr.kny.menu;

import fr.kny.items.armor.ArdentArmorSet;
import fr.kny.items.weapons.CustomWeapon;
import net.kyori.adventure.text.Component;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;

public class WpandamCommand implements CommandExecutor {

    public static final String PERMISSION = "dungeonplugin.wpandam";

    private final CustomWeapon masse;

    public WpandamCommand(CustomWeapon masse) {
        this.masse = masse;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cCette commande est réservée aux joueurs.");
            return true;
        }

        if (!player.hasPermission(PERMISSION)) {
            player.sendMessage(Component.text("§cTu n'as pas la permission d'utiliser cette commande."));
            return true;
        }

        // Pour l'instant une seule colonne (Masse + Armure Ardente) ; on en ajoutera d'autres ici plus tard
        List<WpandamMenu.Column> columns = List.of(
                new WpandamMenu.Column(
                        masse,
                        ArdentArmorSet.HELMET.createItem(),
                        ArdentArmorSet.CHESTPLATE.createItem(),
                        ArdentArmorSet.LEGGINGS.createItem(),
                        ArdentArmorSet.BOOTS.createItem()
                )
        );

        player.openInventory(WpandamMenu.build(columns));
        return true;
    }
}