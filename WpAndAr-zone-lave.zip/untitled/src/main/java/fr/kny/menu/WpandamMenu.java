package fr.kny.menu;

import fr.kny.items.weapons.CustomWeapon;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/**
 * Menu 5 lignes x 9 colonnes.
 * Ligne 0 : arme de la colonne
 * Lignes 1 à 4 : casque / plastron / jambières / bottes du set correspondant
 *
 * Pour l'instant seule la colonne 0 (Masse du Vide) est remplie.
 * Pour ajouter une arme/un set plus tard : ajoute une entrée dans la liste
 * du constructeur avec l'arme et/ou les pièces d'armure correspondantes.
 */
public class WpandamMenu {

    public static final String TITLE = "§8Armes & Armures";
    private static final int SIZE = 45; // 5 lignes de 9

    public record Column(CustomWeapon weapon, ItemStack helmet, ItemStack chestplate,
                         ItemStack leggings, ItemStack boots) {

        public static Column weaponOnly(CustomWeapon weapon) {
            return new Column(weapon, null, null, null, null);
        }
    }

    public static Inventory build(List<Column> columns) {
        WpandamMenuHolder holder = new WpandamMenuHolder();
        Inventory inv = Bukkit.createInventory(holder, SIZE, Component.text(TITLE));
        holder.setInventory(inv);

        ItemStack placeholder = placeholder();

        for (int col = 0; col < 9; col++) {
            Column data = col < columns.size() ? columns.get(col) : null;

            inv.setItem(col, itemOrPlaceholder(data == null ? null : buildWeaponIcon(data.weapon()), placeholder));
            inv.setItem(9 + col, itemOrPlaceholder(data == null ? null : data.helmet(), placeholder));
            inv.setItem(18 + col, itemOrPlaceholder(data == null ? null : data.chestplate(), placeholder));
            inv.setItem(27 + col, itemOrPlaceholder(data == null ? null : data.leggings(), placeholder));
            inv.setItem(36 + col, itemOrPlaceholder(data == null ? null : data.boots(), placeholder));
        }

        return inv;
    }

    private static ItemStack buildWeaponIcon(CustomWeapon weapon) {
        return weapon == null ? null : weapon.createItem();
    }

    private static ItemStack itemOrPlaceholder(ItemStack item, ItemStack placeholder) {
        return item != null ? item : placeholder.clone();
    }

    private static ItemStack placeholder() {
        ItemStack item = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("§7Bientôt disponible"));
        item.setItemMeta(meta);
        return item;
    }
}