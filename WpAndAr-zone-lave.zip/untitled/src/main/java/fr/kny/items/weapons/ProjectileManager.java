package fr.kny.items.weapons;

import fr.kny.items.ItemKeys;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.persistence.PersistentDataType;

public class ProjectileManager implements Listener {

    private final WeaponManager weaponManager;

    public ProjectileManager(WeaponManager weaponManager) {
        this.weaponManager = weaponManager;
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent event) {
        Projectile proj = event.getEntity();

        String id = proj.getPersistentDataContainer()
                .get(ItemKeys.WEAPON_ID, PersistentDataType.STRING);
        if (id == null) return;

        CustomWeapon weapon = weaponManager.get(id);
        if (weapon != null) {
            weapon.onProjectileHit(event);
        }
    }
}