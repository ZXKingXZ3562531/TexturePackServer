package fr.kny.items;

import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;

public class ItemKeys {

    public static NamespacedKey WEAPON_ID;
    public static NamespacedKey ARMOR_SET_ID;
    public static NamespacedKey ARMOR_PIECE_ID;

    // A appeler dans onEnable() du plugin principal, avant tout le reste
    public static void init(JavaPlugin plugin) {
        WEAPON_ID = new NamespacedKey(plugin, "weapon_id");
        ARMOR_SET_ID = new NamespacedKey(plugin, "armor_set_id");
        ARMOR_PIECE_ID = new NamespacedKey(plugin, "armor_piece_id");
    }
}