package fr.kny.items.weapons;

import fr.kny.items.ItemKeys;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Map;

public class WeaponManager implements Listener {

    private final Map<String, CustomWeapon> weapons = new HashMap<>();
    // clé = uuid joueur + ":" + id arme -> timestamp du dernier usage
    private final Map<String, Long> cooldowns = new HashMap<>();

    public void register(CustomWeapon weapon) {
        weapons.put(weapon.getId(), weapon);
    }

    public CustomWeapon get(String id) {
        return weapons.get(id);
    }

    private String getWeaponId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer()
                .get(ItemKeys.WEAPON_ID, PersistentDataType.STRING);
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (!event.getAction().isRightClick()) return;
        // évite de déclencher 2x (main + offhand) sur la même action
        if (event.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        String id = getWeaponId(item);
        if (id == null) return;

        CustomWeapon weapon = weapons.get(id);
        if (weapon == null) return;

        String key = player.getUniqueId() + ":" + id;
        long now = System.currentTimeMillis();
        Long last = cooldowns.get(key);

        if (last != null && now - last < weapon.getCooldownMillis()) {
            long remaining = (weapon.getCooldownMillis() - (now - last)) / 1000 + 1;
            player.sendActionBar(Component.text("§c⏳ Recharge : " + remaining + "s"));
            return;
        }

        cooldowns.put(key, now);
        weapon.onRightClick(player);
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;

        ItemStack item = attacker.getInventory().getItemInMainHand();
        String id = getWeaponId(item);
        if (id == null) return;

        CustomWeapon weapon = weapons.get(id);
        if (weapon != null) {
            weapon.onHit(attacker, event.getEntity());
        }
    }
}