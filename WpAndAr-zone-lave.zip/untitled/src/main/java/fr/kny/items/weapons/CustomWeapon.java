package fr.kny.items.weapons;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.inventory.ItemStack;

public interface CustomWeapon {

    // Identifiant unique stocké dans le PDC de l'item (ex: "masse_du_vide")
    String getId();

    // Crée l'ItemStack complet (nom, lore, custom model data, tag PDC)
    ItemStack createItem();

    // Cooldown de la compétence en millisecondes
    long getCooldownMillis();

    // Appelé quand le joueur fait clic droit avec l'arme en main
    void onRightClick(Player player);

    // Appelé quand le joueur touche une entité avec cette arme (optionnel)
    default void onHit(Player attacker, Entity victim) {}

    // Appelé quand un projectile tiré par cette arme touche un bloc/une entité (optionnel)
    default void onProjectileHit(ProjectileHitEvent event) {}
}