package fr.kny.items.weapons;

import fr.kny.items.ItemKeys;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.SmallFireball;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public class Masse implements CustomWeapon {

    private static final int ZONE_RADIUS = 2;      // rayon de la zone au sol
    private static final long ZONE_DURATION_TICKS = 100L; // 5s avant de remettre les blocs d'origine

    private final Plugin plugin;
    private final Random random = new Random();
    // joueurs actuellement dans leur fenêtre de 5s post-dash
    private final Set<UUID> dashActive = new HashSet<>();

    public Masse(Plugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getId() {
        return "masse_du_vide";
    }

    @Override
    public long getCooldownMillis() {
        return 10_000; // 15s de recharge sur le dash
    }

    @Override
    public ItemStack createItem() {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();

        meta.displayName(Component.text("§c§lMasse Of Ardente"));
        meta.lore(List.of(
                Component.text("§7Clic droit: §fDash"),
                Component.text("§7Touchez un ennemi < 5s pour tirer"),
                Component.text("§7un projectile explosif (-2 coeurs + Lenteur 15s)")
        ));
        meta.setItemModel(new org.bukkit.NamespacedKey("kny", "mace_of_ardente")); // doit correspondre à assets/kny/items/Mace_Of_Ardente.json

        meta.addEnchant(Enchantment.FIRE_ASPECT, 2, true);
        meta.addEnchant(Enchantment.DENSITY, 3, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);

        meta.getPersistentDataContainer()
                .set(ItemKeys.WEAPON_ID, PersistentDataType.STRING, getId());

        item.setItemMeta(meta);
        return item;
    }

    @Override
    public void onRightClick(Player player) {
        Vector dir = player.getLocation().getDirection().normalize().multiply(1.8);

        // Garde un léger "lift" quand on vise à l'horizontale (pour ne pas se vautrer au sol),
        // mais suit vraiment le regard si on vise clairement vers le haut ou le bas.
        if (Math.abs(dir.getY()) < 0.25) {
            dir.setY(0.25);
        }

        player.setVelocity(dir);

        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
        player.sendActionBar(Component.text("§b➤ Dash activé (5s pour toucher)"));

        UUID uuid = player.getUniqueId();
        dashActive.add(uuid);
        Bukkit.getScheduler().runTaskLater(plugin, () -> dashActive.remove(uuid), 100L); // 5s = 100 ticks
    }

    @Override
    public void onHit(Player attacker, Entity victim) {
        UUID uuid = attacker.getUniqueId();
        if (!dashActive.contains(uuid)) return;
        dashActive.remove(uuid);

        // le coup normal de la masse s'applique déjà via le combat vanilla,
        // on ajoute juste le projectile en bonus : une boule de feu qu'on gère nous-mêmes
        SmallFireball proj = attacker.launchProjectile(SmallFireball.class,
                attacker.getLocation().getDirection().multiply(1.8));
        proj.setIsIncendiary(false); // pas de feu random sur le monde, on gère nous-mêmes les dégâts
        proj.setYield(0f);           // pas d'explosion vanilla qui détruit des blocs, notre code s'en charge
        proj.getPersistentDataContainer()
                .set(ItemKeys.WEAPON_ID, PersistentDataType.STRING, getId());

        attacker.getWorld().playSound(attacker.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 1f, 1f);
        attacker.sendActionBar(Component.text("§d✦ Projectile tiré !"));
    }

    @Override
    public void onProjectileHit(ProjectileHitEvent event) {
        Location loc = event.getEntity().getLocation();

        loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1f);
        loc.getWorld().spawnParticle(Particle.EXPLOSION, loc, 1);

        for (Entity nearby : loc.getWorld().getNearbyEntities(loc, 3, 3, 3)) {
            if (nearby instanceof Player target) {
                target.damage(4.0); // 2 coeurs
                target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 300, 0)); // 15s
                target.sendActionBar(Component.text("§4💥 Touché par l'onde de la Masse !"));
            }
        }

        createHazardZone(loc);
    }

    // Transforme temporairement le sol autour du point d'impact en netherrack/magma_block/lave,
    // puis remet les blocs d'origine après ZONE_DURATION_TICKS.
    private void createHazardZone(Location impact) {
        Block base = impact.getBlock();
        // redescend jusqu'au premier bloc solide sous le point d'impact
        while (base.getType().isAir() && base.getY() > base.getWorld().getMinHeight()) {
            base = base.getRelative(BlockFace.DOWN);
        }

        List<BlockState> originalStates = new ArrayList<>();

        for (int dx = -ZONE_RADIUS; dx <= ZONE_RADIUS; dx++) {
            for (int dz = -ZONE_RADIUS; dz <= ZONE_RADIUS; dz++) {
                if (dx * dx + dz * dz > ZONE_RADIUS * ZONE_RADIUS) continue; // forme circulaire

                Block block = base.getRelative(dx, 0, dz);
                originalStates.add(block.getState()); // sauvegarde l'état d'origine pour le restaurer

                if (dx == 0 && dz == 0) {
                    block.setType(Material.LAVA);
                } else {
                    block.setType(random.nextBoolean() ? Material.NETHERRACK : Material.MAGMA_BLOCK);
                }
            }
        }

        // Remet les blocs d'origine après 5 secondes
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            for (BlockState state : originalStates) {
                state.update(true, false);
            }
        }, ZONE_DURATION_TICKS);
    }
}
