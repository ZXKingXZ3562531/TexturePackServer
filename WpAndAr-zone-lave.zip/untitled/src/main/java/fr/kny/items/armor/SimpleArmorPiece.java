package fr.kny.items.armor;

import fr.kny.items.ItemKeys;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.EquippableComponent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;

import java.util.List;
import java.util.Map;

/**
 * Implémentation générique d'une pièce d'armure custom : une seule classe suffit
 * pour définir une pièce (matériau, nom, lore, item model, enchants, effet de potion).
 * Pour ajouter un nouveau set, il suffit d'instancier 4 SimpleArmorPiece (voir ArdentArmorSet).
 */
public class SimpleArmorPiece implements CustomArmorPiece {

    private final String id;
    private final String setId;
    private final EquipmentSlot slot;
    private final Material material;
    private final Component displayName;
    private final List<Component> lore;
    private final NamespacedKey itemModel;      // apparence dans l'inventaire / en main (kny:netherite_...)
    private final NamespacedKey equipmentAsset; // apparence sur le corps du joueur (partagée par tout le set), peut être null
    private final Map<Enchantment, Integer> enchants;
    private final PotionEffect potionEffect;    // effet appliqué tant que la pièce est portée, peut être null

    public SimpleArmorPiece(String id, String setId, EquipmentSlot slot, Material material,
                             Component displayName, List<Component> lore,
                             NamespacedKey itemModel, NamespacedKey equipmentAsset,
                             Map<Enchantment, Integer> enchants, PotionEffect potionEffect) {
        this.id = id;
        this.setId = setId;
        this.slot = slot;
        this.material = material;
        this.displayName = displayName;
        this.lore = lore;
        this.itemModel = itemModel;
        this.equipmentAsset = equipmentAsset;
        this.enchants = enchants;
        this.potionEffect = potionEffect;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getSetId() {
        return setId;
    }

    @Override
    public EquipmentSlot getSlot() {
        return slot;
    }

    @Override
    public ItemStack createItem() {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();

        meta.displayName(displayName);
        meta.lore(lore);

        // Apparence custom dans l'inventaire / en main : doit correspondre à
        // assets/kny/items/<nom>.json dans le resource pack
        meta.setItemModel(itemModel);

        // Apparence custom une fois portée sur le corps (system d'équipement 1.21.2+) :
        // doit correspondre à assets/kny/equipment/<equipmentAsset>.png (+ .json)
        EquippableComponent equippable = meta.getEquippable();
        if (equippable != null) {
            equippable.setSlot(slot); // important : sinon le composant repart sur HEAD par défaut
            if (equipmentAsset != null) {
                equippable.setModel(equipmentAsset);
            }
            meta.setEquippable(equippable);
        }

        enchants.forEach((enchant, level) -> meta.addEnchant(enchant, level, true));

        meta.getPersistentDataContainer().set(ItemKeys.ARMOR_PIECE_ID, PersistentDataType.STRING, id);
        meta.getPersistentDataContainer().set(ItemKeys.ARMOR_SET_ID, PersistentDataType.STRING, setId);

        item.setItemMeta(meta);
        return item;
    }

    @Override
    public void onEquip(Player player) {
        if (potionEffect != null) {
            player.addPotionEffect(potionEffect);
        }
    }

    @Override
    public void onUnequip(Player player) {
        if (potionEffect != null) {
            player.removePotionEffect(potionEffect.getType());
        }
    }
}
