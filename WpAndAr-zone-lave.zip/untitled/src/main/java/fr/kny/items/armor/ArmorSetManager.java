package fr.kny.items.armor;

import fr.kny.items.ItemKeys;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * Il n'existe pas d'event Bukkit/Paper vanilla fiable qui couvre TOUS les cas
 * d'équipement/déséquipement d'armure (clic droit, shift-clic, dispenser,
 * armure qui casse, mort, /item, etc.). On vérifie donc périodiquement
 * l'armure de chaque joueur et on compare avec son état précédent.
 */
public class ArmorSetManager implements Listener {

    private final Map<String, CustomArmorPiece> pieces = new HashMap<>();
    // dernier état connu de l'armure de chaque joueur : [bottes, jambières, plastron, casque]
    private final Map<UUID, String[]> lastKnownArmor = new HashMap<>();

    public void register(CustomArmorPiece piece) {
        pieces.put(piece.getId(), piece);
    }

    private String getPieceId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer()
                .get(ItemKeys.ARMOR_PIECE_ID, PersistentDataType.STRING);
    }

    // A appeler une fois dans onEnable() pour démarrer la vérification périodique
    public void startTracking(Plugin plugin) {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : plugin.getServer().getOnlinePlayers()) {
                    checkArmor(player);
                }
            }
        }.runTaskTimer(plugin, 10L, 10L); // vérifie toutes les 0.5s (10 ticks)
    }

    private void checkArmor(Player player) {
        ItemStack[] contents = player.getInventory().getArmorContents(); // ordre: bottes, jambières, plastron, casque
        String[] current = new String[contents.length];
        for (int i = 0; i < contents.length; i++) {
            current[i] = getPieceId(contents[i]);
        }

        String[] previous = lastKnownArmor.getOrDefault(player.getUniqueId(), new String[contents.length]);

        for (int i = 0; i < contents.length; i++) {
            if (Objects.equals(previous[i], current[i])) continue;

            if (previous[i] != null) {
                CustomArmorPiece oldPiece = pieces.get(previous[i]);
                if (oldPiece != null) oldPiece.onUnequip(player);
            }
            if (current[i] != null) {
                CustomArmorPiece newPiece = pieces.get(current[i]);
                if (newPiece != null) newPiece.onEquip(player);
            }
        }

        lastKnownArmor.put(player.getUniqueId(), current);
    }

    // Applique direct les effets si le joueur rejoint déjà équipé
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        checkArmor(event.getPlayer());
    }

    // Evite de garder des états en mémoire pour rien
    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        lastKnownArmor.remove(event.getPlayer().getUniqueId());
    }
}
