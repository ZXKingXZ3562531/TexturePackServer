package fr.kny.items.armor;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.List;
import java.util.Map;

/**
 * "Armure Ardente" : set complet en Netherite (assorti à la Masse Of Ardente).
 * Chaque pièce a son propre item model, son propre enchant phare, et son propre
 * effet de potion actif tant qu'elle est portée (retiré dès qu'elle est retirée).
 *
 * Resource pack attendu (namespace "kny") :
 *   assets/kny/items/netherite_helmet.json
 *   assets/kny/items/netherite_chestplate.json
 *   assets/kny/items/netherite_leggings.json
 *   assets/kny/items/netherite_boots.json
 *   assets/kny/equipment/netherite_ardente.json   (+ .png) -> texture portée sur le corps, partagée par les 4 pièces
 */
public final class ArdentArmorSet {

    public static final String SET_ID = "armure_ardente";

    // Texture "portée" commune aux 4 pièces (système d'équipement 1.21.2+)
    private static final NamespacedKey EQUIPMENT_ASSET = new NamespacedKey("kny", "netherite_ardente");

    // Durée "infinie" pour un effet de potion (Minecraft interprète -1 comme illimité, ex: /effect ... infinite)
    private static final int INFINITE = -1;

    public static final SimpleArmorPiece HELMET = new SimpleArmorPiece(
            "armure_ardente_casque", SET_ID, EquipmentSlot.HEAD, Material.NETHERITE_HELMET,
            Component.text("§6§lCasque Ardent"),
            List.of(
                    Component.text("§7Vision nocturne tant qu'il est porté."),
                    Component.text("§8« Voir clair même dans la fumée. »")
            ),
            new NamespacedKey("kny", "netherite_helmet"),
            EQUIPMENT_ASSET,
            Map.of(
                    Enchantment.PROTECTION, 4,
                    Enchantment.UNBREAKING, 3,
                    Enchantment.RESPIRATION, 3
            ),
            new PotionEffect(PotionEffectType.NIGHT_VISION, INFINITE, 0, true, false)
    );

    public static final SimpleArmorPiece CHESTPLATE = new SimpleArmorPiece(
            "armure_ardente_plastron", SET_ID, EquipmentSlot.CHEST, Material.NETHERITE_CHESTPLATE,
            Component.text("§6§lPlastron Ardent"),
            List.of(
                    Component.text("§7Résistance au feu tant qu'il est porté."),
                    Component.text("§8« La lave n'est qu'un souvenir. »")
            ),
            new NamespacedKey("kny", "netherite_chestplate"),
            EQUIPMENT_ASSET,
            Map.of(
                    Enchantment.PROTECTION, 4,
                    Enchantment.UNBREAKING, 3,
                    Enchantment.THORNS, 3
            ),
            new PotionEffect(PotionEffectType.FIRE_RESISTANCE, INFINITE, 0, true, false)
    );

    public static final SimpleArmorPiece LEGGINGS = new SimpleArmorPiece(
            "armure_ardente_jambieres", SET_ID, EquipmentSlot.LEGS, Material.NETHERITE_LEGGINGS,
            Component.text("§6§lJambières Ardentes"),
            List.of(
                    Component.text("§7Vitesse tant qu'elles sont portées."),
                    Component.text("§8« Le feu au pied. »")
            ),
            new NamespacedKey("kny", "netherite_leggings"),
            EQUIPMENT_ASSET,
            Map.of(
                    Enchantment.PROTECTION, 4,
                    Enchantment.UNBREAKING, 3,
                    Enchantment.SWIFT_SNEAK, 3
            ),
            new PotionEffect(PotionEffectType.SPEED, INFINITE, 0, true, false)
    );

    public static final SimpleArmorPiece BOOTS = new SimpleArmorPiece(
            "armure_ardente_bottes", SET_ID, EquipmentSlot.FEET, Material.NETHERITE_BOOTS,
            Component.text("§6§lBottes Ardentes"),
            List.of(
                    Component.text("§7Chute de plume tant qu'elles sont portées."),
                    Component.text("§8« Tu ne touches jamais vraiment le sol. »")
            ),
            new NamespacedKey("kny", "netherite_boots"),
            EQUIPMENT_ASSET,
            Map.of(
                    Enchantment.PROTECTION, 4,
                    Enchantment.UNBREAKING, 3,
                    Enchantment.FEATHER_FALLING, 4
            ),
            new PotionEffect(PotionEffectType.SLOW_FALLING, INFINITE, 0, true, false)
    );

    public static void registerAll(ArmorSetManager manager) {
        manager.register(HELMET);
        manager.register(CHESTPLATE);
        manager.register(LEGGINGS);
        manager.register(BOOTS);
    }

    private ArdentArmorSet() {}
}
