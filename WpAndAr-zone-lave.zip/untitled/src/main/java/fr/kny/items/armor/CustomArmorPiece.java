package fr.kny.items.armor;

import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public interface CustomArmorPiece {

    // Identifiant unique stocké dans le PDC de l'item (ex: "armure_ardente_casque")
    String getId();

    // Identifiant du set auquel appartient la pièce (ex: "armure_ardente")
    String getSetId();

    // Emplacement d'équipement concerné (HEAD, CHEST, LEGS, FEET)
    EquipmentSlot getSlot();

    // Crée l'ItemStack complet (nom, lore, enchants, item model, tags PDC)
    ItemStack createItem();

    // Appelé quand le joueur enfile la pièce (applique l'effet de potion)
    void onEquip(Player player);

    // Appelé quand le joueur retire la pièce (retire l'effet de potion)
    void onUnequip(Player player);
}
