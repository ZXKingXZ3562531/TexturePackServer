package fr.kny;

import fr.kny.items.ItemKeys;
import fr.kny.items.armor.ArdentArmorSet;
import fr.kny.items.armor.ArmorSetManager;
import fr.kny.items.weapons.Masse;
import fr.kny.items.weapons.ProjectileManager;
import fr.kny.items.weapons.WeaponManager;
import fr.kny.menu.WpandamCommand;
import fr.kny.menu.WpandamListener;
import org.bukkit.plugin.java.JavaPlugin;

public class WpAndAr extends JavaPlugin {

    @Override
    public void onEnable() {
        // Initialise les clés PDC (identification des armes/armures) - à faire en premier
        ItemKeys.init(this);

        // --- Armes ---
        WeaponManager weaponManager = new WeaponManager();
        Masse masse = new Masse(this);
        weaponManager.register(masse);
        // weaponManager.register(new AutreArme(this)); // pour tes futures armes

        getServer().getPluginManager().registerEvents(weaponManager, this);
        getServer().getPluginManager().registerEvents(new ProjectileManager(weaponManager), this);

        // --- Armures ---
        ArmorSetManager armorSetManager = new ArmorSetManager();
        ArdentArmorSet.registerAll(armorSetManager);
        getServer().getPluginManager().registerEvents(armorSetManager, this);
        armorSetManager.startTracking(this);

        // --- Menu /wpandam ---
        getServer().getPluginManager().registerEvents(new WpandamListener(), this);
        getCommand("wpandam").setExecutor(new WpandamCommand(masse));

        getLogger().info("WpAndAr activé !");
    }

    @Override
    public void onDisable() {
        getLogger().info("WpAndAr désactivé.");
    }
}